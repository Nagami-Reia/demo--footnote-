"""Build a local, offline PDF research library from your own sources."""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import tempfile
import unicodedata
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from urllib.parse import quote

import pdfplumber
import pypdfium2

from extractor import extract


ASSETS = Path(__file__).resolve().parent / "assets"
FORMS = {
    "UND": "形态待核", "MON": "专著", "BIO": "传记", "MEM": "回忆录",
    "ART": "论文", "COL": "文集", "DOC": "文献选编", "COR": "书信",
    "DIA": "日记", "SRC": "原始史料", "CAT": "图录", "EDU": "教学资料",
    "FIC": "文学作品",
}


def read_json(path, default):
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_jsonl(path, rows):
    with path.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")


def fingerprint(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def find_sources(root):
    found = {}
    for path in sorted(root.rglob("*")):
        if path.suffix.lower() != ".pdf" or not path.is_file():
            continue
        if not path.resolve().is_relative_to(root.resolve()):
            raise ValueError(f"PDF 链接指向 sources 目录之外：{path.relative_to(root)}")
        digest = fingerprint(path)
        found.setdefault(digest, path)
    return found


def book_number(registry, digest):
    if digest not in registry:
        registry[digest] = f"LIT-D{len(registry) + 1:06d}"
    return registry[digest]


def inspect_source(path):
    with pdfplumber.open(path) as pdf:
        title = str(pdf.metadata.get("Title") or "").strip()
        author = str(pdf.metadata.get("Author") or "").strip()
    with pypdfium2.PdfDocument(path) as doc:
        outlines = []
        for item in doc.get_toc():
            destination = item.get_dest()
            if item.level == 0 and destination is not None:
                index = destination.get_index()
                if index is not None and 0 <= index < len(doc):
                    outlines.append((index + 1, item.get_title()))
        return {"title": title or path.stem, "author": author, "pages": len(doc),
                "outlines": sorted(outlines, key=lambda item: item[0])}


def ocr_page(doc, page, language, engine, cache):
    output = cache / f"{page:06d}.json"
    if output.exists():
        return read_json(output, [])
    cache.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as scratch:
        image = Path(scratch) / "page.png"
        source_page = doc[page - 1]
        bitmap = source_page.render(scale=3, grayscale=True)
        try:
            bitmap.to_pil().save(image)
        finally:
            bitmap.close()
            source_page.close()
        result = subprocess.run(
            [engine, str(image), "stdout", "-l", language, "tsv"],
            capture_output=True, text=True, encoding="utf-8", check=False,
        )
        if result.returncode:
            raise ValueError(f"PDF 第 {page} 页 OCR 失败：{result.stderr.strip()}")
    paragraphs = defaultdict(lambda: defaultdict(list))
    fields = ("level", "page_num", "block_num", "par_num", "line_num", "word_num",
              "left", "top", "width", "height", "conf", "text")
    for word in csv.DictReader(io.StringIO(result.stdout), fieldnames=fields,
                               delimiter="\t", quoting=csv.QUOTE_NONE):
        if word.get("level") == "5" and (word.get("text") or "").strip():
            paragraphs[word["block_num"], word["par_num"]][word["line_num"]].append(word["text"])
    rows = []
    for index, lines in enumerate(paragraphs.values(), 1):
        raw = "\n".join(" ".join(words) for words in lines.values())
        rows.append({"id": f"OCR-{language}-{page:06d}-{index:04d}",
                     "pdf_page": page, "text_raw_lines": raw, "record_type": "text",
                     "ocr_review_status": "OCR待核图：自动识别，引用前请对照原页",
                     "quality_flags": []})
    write_json(output, rows)
    return rows


def searchable(text):
    clean = unicodedata.normalize("NFKC", " ".join(text.split()))
    return re.sub(r"(?<=[\u3400-\u9fff])\s+(?=[\u3400-\u9fff])", "", clean)


def local_preview(text):
    """Select a representative sentence in the source language, without a model."""
    sentences = [s.strip() for s in re.split(r'(?<=[。！？!?])|(?<=[.])\s+(?=[A-Z])', text)
                 if s.strip()]
    if not sentences:
        return ""
    def terms(sentence):
        words = re.findall(r"\b[A-Za-zÀ-ÿ]{3,}\b", sentence.lower())
        for run in re.findall(r"[\u3400-\u9fff]+", sentence):
            words.extend(run[i:i+2] for i in range(len(run)-1))
        return words
    frequencies = Counter(terms(text))
    def score(sentence):
        words = terms(sentence)
        return sum(frequencies[word] for word in set(words)) / max(1,len(words))**0.7
    selected = max(sentences, key=score)
    return selected if len(selected) <= 240 else selected[:240] + "…"


def read_annotations(directory):
    annotations = {}
    for file in sorted(directory.glob("*.jsonl")):
        for number, line in enumerate(file.read_text(encoding="utf-8-sig").splitlines(), 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                key = row["record_uid"]
                if not all(isinstance(row.get(k), str) and row[k].strip()
                           for k in ("record_uid", "summary_zh", "uses_zh")):
                    raise ValueError("须填写 record_uid、summary_zh、uses_zh")
                if key in annotations and annotations[key] != row:
                    raise ValueError(f"有冲突的重复条目 {key}")
                annotations[key] = row
            except (ValueError, KeyError, TypeError) as error:
                raise ValueError(f"{file.name} 第 {number} 行：{error}") from error
    return annotations


def citation_templates(book, meta):
    names = book["author"]
    editors = meta.get("editors", [])
    translators = meta.get("translators", [])
    title = book["title"]
    edition = f", {meta['edition']}" if meta.get("edition") else ""
    roles = ""
    if editors:
        roles += ", ed. " + " and ".join(editors)
    if translators:
        roles += ", trans. " + " and ".join(translators)
    publication = ": ".join(part for part in (meta.get("place"), meta.get("publisher")) if part)
    year = book["year"] or "n.d."
    imprint = f"{publication}, {year}" if publication else str(year)
    if not meta.get("author") and editors:
        names = " and ".join(editors) + (", eds." if len(editors) > 1 else ", ed.")
        roles = ", trans. " + " and ".join(translators) if translators else ""
    lead = f"{names}, " if names else ""
    return f"{lead}{title}{roles}{edition} ({imprint}), {{page}}", f"{lead}{title}, {{page}}"


def make_book(doc_id, path, source, meta, agents):
    info = inspect_source(path)
    meta = dict(meta)
    form = meta.get("form", "UND")
    if form not in FORMS:
        raise ValueError(f"{doc_id} 的 form 不存在：{form}")
    start, end = meta.get("body_start", 1), meta.get("body_end", info["pages"])
    if not 1 <= start <= end <= info["pages"]:
        raise ValueError(f"{doc_id} 的正文页界超出 PDF")
    authors = meta.get("author", info["author"])
    creators = []
    for role, names in (("author", [authors] if authors else []),
                        ("editor", meta.get("editors", [])),
                        ("translator", meta.get("translators", []))):
        for name in names:
            identity = hashlib.sha256(f"{doc_id}\n{role}\n{name}".encode()).hexdigest()[:16]
            agent = agents.setdefault(identity, {"agent_id": f"A-{identity}", "authorized_name": name})
            creators.append({"agent_id": agent["agent_id"], "role": role})
    book = {"id": doc_id, "title": meta.get("title") or info["title"],
            "author": authors, "year": meta.get("year"), "form": form, "form_label": FORMS[form],
            "subjects": meta.get("subjects", []), "creators": creators, "pages": info["pages"],
            "source_file": "../sources/" + quote(path.relative_to(source).as_posix()),
            "source_path": path.relative_to(source).as_posix(),
            "catalog_review_status": "书目已核" if meta.get("verified") else "书目候选，待核题名页"}
    return book, info, start, end


def make_records(rows, book, info, meta, start, end, digest, annotations, previews):
    counters = Counter()
    for row in rows:
        page = row["pdf_page"]
        raw = row["text_raw_lines"]
        kind = row["record_type"]
        if meta.get("notes_start", info["pages"] + 1) <= page <= meta.get("notes_end", info["pages"]):
            if kind == "text":
                kind = "note"
        token = {"text": "T", "heading": "H", "note": "N", "caption": "C"}[kind]
        counters[page, token] += 1
        # Scope identity to this PDF and this exact extraction unit.
        identity = hashlib.sha256(f"{digest}\0{row['id']}\0{raw}".encode()).hexdigest()[:24]
        uid = f"LIT-U{identity}"
        section = "front" if page < start else "back" if page > end else "body"
        chapter = next((title for number, title in reversed(info["outlines"]) if number <= page), "未分章")
        summary = annotations.get(uid, {})
        text = searchable(raw)
        yield {
            "id": uid, "record_uid": uid, "legacy_id": uid,
            "reference_code": f"LIT-{book['form']}-{book['id'][4:]}-F001-P{page:06d}-{token}{counters[page, token]:04d}",
            "book_id": book["id"], "pdf_page": page, "chapter": chapter,
            "record_type": kind, "section_type": section, "quote_text": raw, "text": text,
            "summary_zh": summary.get("summary_zh"), "uses_zh": summary.get("uses_zh"),
            "local_preview": local_preview(text) if previews and not summary and section=="body" and kind=="text" else "",
            "summary_status": "详细中文摘要" if summary else "待详细中文摘要",
            "ocr_review_status": row["ocr_review_status"], "quality_flags": row.get("quality_flags", []),
            "citation_status": book["catalog_review_status"], "bbox": row.get("bbox"),
        }


def connect_records(rows):
    for index, row in enumerate(rows):
        previous = rows[index - 1] if index else None
        following = rows[index + 1] if index + 1 < len(rows) else None
        row["previous_id"] = previous["id"] if previous else None
        row["next_id"] = following["id"] if following else None
        row["continues_previous"] = bool(previous
            and previous["record_type"] == row["record_type"] == "text"
            and previous["pdf_page"] + 1 == row["pdf_page"]
            and previous["chapter"] == row["chapter"]
            and not re.search(r"[。！？.!?][”’\"']?$", previous["text"]))
        if previous:
            previous["continues_next"] = row["continues_previous"]


def write_database(out, books, rows, pages):
    with sqlite3.connect(out / "library.sqlite") as db:
        db.executescript("""
            PRAGMA foreign_keys=ON;
            CREATE TABLE documents(id TEXT PRIMARY KEY, title TEXT, source TEXT, pages INTEGER, data_json TEXT);
            CREATE TABLE units(record_uid TEXT PRIMARY KEY, document_id TEXT REFERENCES documents(id),
                pdf_page INTEGER, reference_code TEXT UNIQUE, original TEXT, search_text TEXT,
                summary_zh TEXT, uses_zh TEXT, data_json TEXT);
            CREATE INDEX units_page ON units(document_id, pdf_page);
            CREATE TABLE page_status(document_id TEXT REFERENCES documents(id),
                pdf_page INTEGER, status TEXT, PRIMARY KEY(document_id,pdf_page));
        """)
        db.executemany("INSERT INTO documents VALUES(?,?,?,?,?)",
            ((b["id"], b["title"], b["source_file"], b["pages"], json.dumps(b,ensure_ascii=False)) for b in books))
        db.executemany("INSERT INTO units VALUES(?,?,?,?,?,?,?,?,?)",
            ((r["id"],r["book_id"],r["pdf_page"],r["reference_code"],r["quote_text"],r["text"],
              r["summary_zh"],r["uses_zh"],json.dumps(r,ensure_ascii=False)) for r in rows))
        db.executemany("INSERT INTO page_status VALUES(?,?,?)", pages)
        if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("SQLite 完整性核验失败")
        if db.execute("PRAGMA foreign_key_check").fetchone():
            raise ValueError("SQLite 存在孤立记录")


def publish(project, staged):
    destination = project / "library"
    backup = staged.parent / "previous"
    if destination.exists():
        destination.rename(backup)
    try:
        staged.rename(destination)
    except OSError:
        if backup.exists():
            backup.rename(destination)
        raise


def generate(project, ocr_language, workers, previews):
    source = project / "sources"
    cache = project / ".cache"
    registry_path = project / "registry.json"
    source.mkdir(exist_ok=True)
    cache.mkdir(exist_ok=True)
    paths = find_sources(source)
    if not paths:
        raise ValueError("请先把至少一个 PDF 放入 sources 文件夹。")
    engine = shutil.which("tesseract") if ocr_language else None
    if ocr_language and not engine:
        raise ValueError("启用 OCR 需要本机安装 Tesseract 和对应语言包。")
    ocr_profile = cache / "ocr-language.json"
    cached_language = ocr_language or read_json(ocr_profile, None)
    meta = read_json(project / "metadata.json", {})
    annotations = read_annotations(project / "annotations")
    registry = read_json(registry_path, {})
    if len(set(registry.values())) != len(registry):
        raise ValueError("registry.json 中存在重复文献号。")
    inputs = [{"legacy_id": book_number(registry,digest), "sha256": digest, "path": str(path)}
              for digest,path in paths.items()]
    native = cache / "native"
    with ProcessPoolExecutor(max_workers=workers) as pool:
        jobs = {pool.submit(extract, row, native):row for row in inputs}
        for job,row in jobs.items():
            result = job.result()
            print(row["legacy_id"], Path(row["path"]).name,
                  "复用提取缓存" if result.get("status") == "cached" else f"提取 {result['records']} 条", flush=True)
    all_rows, books, pages = [], [], []
    agents, subjects, templates = {}, {}, []
    for item in inputs:
        doc_id, digest, path = item["legacy_id"], item["sha256"], Path(item["path"])
        metadata = meta.get(doc_id, {})
        book, info, start, end = make_book(doc_id, path, source, metadata, agents)
        rows = read_json(native / f"{doc_id}-records.json", [])
        ledger = read_json(native / f"{doc_id}-pages.json", [])
        if cached_language:
            model_key = hashlib.sha256(cached_language.encode()).hexdigest()[:12]
            ocr_cache = cache/"ocr"/digest/model_key
            with pypdfium2.PdfDocument(path) as doc:
                for entry in ledger:
                    if entry["status"] == "ocr_required":
                        page = entry["pdf_page"]
                        saved = ocr_cache / f"{page:06d}.json"
                        if not engine and not saved.exists():
                            continue
                        recognized = ocr_page(doc, page, cached_language, engine, ocr_cache)
                        rows.extend(recognized)
                        entry["status"] = "ocr_candidate" if recognized else "ocr_no_text"
        rows.sort(key=lambda row: (row["pdf_page"], row["id"]))
        records = list(make_records(rows,book,info,metadata,start,end,digest,annotations,previews))
        connect_records(records)
        targets = [r for r in records if r["section_type"]=="body" and r["record_type"]=="text"]
        book["body_records"] = len(targets)
        book["detailed_records"] = sum(bool(r["summary_zh"]) for r in targets)
        book["pending_records"] = len(targets) - book["detailed_records"]
        book["ocr_pending_pages"] = sum(p["status"]=="ocr_required" for p in ledger)
        book["ocr_candidate_pages"] = sum(p["status"]=="ocr_candidate" for p in ledger)
        for subject in book["subjects"]:
            subjects[subject] = subject
        templates.append(citation_templates(book,metadata))
        for r in records:
            page_label = f"PDF p. {r['pdf_page']}."
            r["citation_full"],r["citation_short"] = [s.replace("{page}",page_label) for s in templates[-1]]
        books.append(book)
        all_rows.extend(records)
        pages.extend((doc_id,p["pdf_page"],p["status"]) for p in ledger)
    with tempfile.TemporaryDirectory(prefix="build-",dir=cache) as scratch:
        out = Path(scratch) / "library"
        shutil.copytree(ASSETS,out)
        (out/"books").mkdir()
        by_book = defaultdict(list)
        for row in all_rows:
            by_book[row["book_id"]].append(row)
        for b in books:
            with (out/"books"/f"{b['id']}.md").open("w", encoding="utf-8") as stream:
                stream.write(f"# {b['title']}\n\n")
                for r in by_book[b["id"]]:
                    stream.write(f"## {r['reference_code']}\n\n{r['id']} · {r['ocr_review_status']}\n\n")
                    if r["summary_zh"]:
                        stream.write(f"{r['summary_zh']}\n\n用途：{r['uses_zh']}\n\n")
                    stream.write("\n".join("> "+line for line in r["quote_text"].splitlines()))
                    stream.write(f"\n\n{r['citation_full']}\n\n[PDF 原页](../{b['source_file']}#page={r['pdf_page']})\n\n")
        fields = ["id","reference_code","legacy_id","book_id","pdf_page","chapter","record_type","section_type",
                  "quote_text","summary_zh","uses_zh","summary_status","ocr_review_status","quality_flags",
                  "previous_id","next_id","continues_previous","continues_next","citation_status","local_preview"]
        indices = {b["id"]: i for i,b in enumerate(books)}
        ui_rows = [[*(r.get(key) for key in fields), indices[r["book_id"]],
                    None if r["text"] == r["quote_text"].replace("\n"," ") else r["text"]]
                   for r in all_rows]
        payload = dict(books=books, records=ui_rows, aliases={}, agents=list(agents.values()),
                       classification=dict(form_codes=FORMS,subject_codes=subjects),
                       keyword_aliases=read_json(project/"同义词.json",{}),
                       record_fields=fields,citation_templates=templates)
        script = json.dumps(payload,ensure_ascii=False,separators=(",",":")).replace("</","<\\/")
        (out/"library-data.js").write_text("window.LITERATURE_LIBRARY="+script+";\n", encoding="utf-8")
        write_json(out/"books.json",books)
        write_json(out/"agents.json",list(agents.values()))
        write_jsonl(out/"records.jsonl",all_rows)
        write_jsonl(out/"摘要任务.jsonl",(
            {k:r[k] for k in ("record_uid","book_id","pdf_page","chapter","quote_text","ocr_review_status")}
            for r in all_rows if r["section_type"]=="body" and r["record_type"]=="text" and not r["summary_zh"]
        ))
        write_database(out,books,all_rows,pages)
        shutil.copy2(Path(__file__).resolve().parent/"使用说明.md",out/"使用说明.md")
        temporary_registry=cache/"registry.tmp"
        write_json(temporary_registry,registry)
        # Assignments remain reserved even if the final directory swap fails.
        os.replace(temporary_registry,registry_path)
        publish(project,out)
    if ocr_language:
        write_json(ocr_profile,ocr_language)
    unmatched = len(annotations.keys() - {r["record_uid"] for r in all_rows})
    if unmatched:
        print(f"{unmatched} 条摘要未匹配当前文献，原摘要文件已保留。")
    print(f"生成完成：{len(books)} 份文献，{len(all_rows)} 条文字记录。\n{project/'library'/'index.html'}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--ocr", metavar="LANG", help="对无文字层图页启用本机 Tesseract，如 chi_sim+eng")
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--no-previews", action="store_true", help="关闭本地摘句速览")
    args = parser.parse_args()
    if not 1 <= args.workers <= 8:
        parser.error("--workers 需在 1 到 8 之间")
    project = args.project.resolve()
    project.mkdir(parents=True,exist_ok=True)
    lock = project / ".build.lock"
    try:
        lock.mkdir()
    except FileExistsError:
        parser.exit(1,"另一个生成任务正在运行。若上次异常退出，确认已停止后可删空的 .build.lock 文件夹。\n")
    try:
        generate(project,args.ocr,args.workers,not args.no_previews)
    except (ValueError, OSError) as error:
        parser.exit(1,f"生成失败：{error}\n")
    finally:
        lock.rmdir()


if __name__ == "__main__":
    main()
