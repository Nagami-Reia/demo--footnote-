#!/bin/zsh
set -e
cd -- "${0:A:h}"
if [[ ! -x .venv/bin/python ]]; then
  python3 -m venv .venv
fi
if [[ ! -f .venv/dependencies-ready || requirements.txt -nt .venv/dependencies-ready ]]; then
  .venv/bin/python -m pip install -r requirements.txt
  touch .venv/dependencies-ready
fi
.venv/bin/python build.py "$@"
open library/index.html
