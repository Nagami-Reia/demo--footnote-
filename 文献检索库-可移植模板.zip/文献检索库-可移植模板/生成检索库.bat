@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 goto failed
)
if not exist ".venv\dependencies-ready" (
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto failed
  type nul > ".venv\dependencies-ready"
)
".venv\Scripts\python.exe" build.py %*
if errorlevel 1 goto failed
start "" "%CD%\library\index.html"
exit /b 0
:failed
pause
exit /b 1
