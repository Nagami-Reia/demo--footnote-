const library = window.LITERATURE_LIBRARY;
const {books,aliases:aliasMap,agents,classification} = library;
if (library.record_fields) {
    const bookIndex = new Map(books.map(book => [book.id, book]));
    const fields = library.record_fields;
    library.records = library.records.map(values => {
        const record = {};
        fields.forEach((field,index) => record[field] = values[index]);
        const book = bookIndex.get(record.book_id);
        const citations = library.citation_templates[values[fields.length]];
        const page = 'PDF p. '+record.pdf_page+'.';
        Object.assign(record, {
            record_uid:record.id,
            book_title:book.title, book_author:book.author, form:book.form,
            subjects:book.subjects, creators:book.creators,
            text:values[fields.length+1] ?? record.quote_text.replace(/\n/g,' '),
            source_link:book.source_file+'#page='+record.pdf_page,
            citation_full:citations[0].replace('{page}', page),
            citation_short:citations[1].replace('{page}', page)
        });
        return record;
    });
}
const {records}=library;const $=s=>document.querySelector(s);const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const norm=s=>String(s??'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase();let page=0,matched=[];const pageSize=30;
const byid = new Map();
for (const record of records) {
    byid.set(record.id, record);
    byid.set(record.legacy_id, record);
    byid.set(record.reference_code, record);
}
for (const [alias,id] of Object.entries(aliasMap)) {
    const record = byid.get(id);
    if (record) byid.set(alias, record);
}
const aliases=library.keyword_aliases || Object.create(null);
const alphabetical = new Intl.Collator('zh-Hans-u-co-pinyin', {sensitivity:'base', numeric:true});
function sortedBy(items, label) {
    return [...items].sort((a,b) => alphabetical.compare(label(a), label(b)));
}
function addOption(select, value, label) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    $(select).append(option);
}
for(const [code,label] of sortedBy(Object.entries(classification.form_codes), ([code]) => code))
    addOption('#form', code, code+' '+label);
for(const [code,label] of sortedBy(Object.entries(classification.subject_codes), ([code]) => code))
    addOption('#subject', code, code+' '+label);
const sortedAgents = sortedBy(agents, a => a.authorized_name);
for(const a of sortedAgents) {
    const dates = a.birth_year ? ' ('+a.birth_year+(a.death_year?'–'+a.death_year:'年生')+')' : '';
    addOption('#creator', a.agent_id, a.authorized_name+dates+' ['+a.agent_id+']');
}
const sortedBooks = sortedBy(books, b => b.title);
for(const b of sortedBooks) addOption('#book', b.id, b.title+' ['+b.id+' · '+b.form+']');
$('#books').innerHTML='<table><thead><tr><th>文献号 / 分类</th><th>作者与题名</th><th>PDF 页</th><th>正文条目</th><th>详细摘要 / 待摘要</th><th>原件与校核</th></tr></thead><tbody>'+sortedBooks.map(b=>`<tr><td>${esc(b.id)}<br>${esc(b.form)} ${esc(b.form_label)}</td><td>${esc(b.author)}<br><i>${esc(b.title)}</i> (${b.year??'无日期'})</td><td>${b.pages}</td><td>${b.body_records}</td><td>${b.detailed_records} / ${b.pending_records}</td><td><a href="books/${b.id}.md">Markdown</a> | <a href="${esc(b.source_file)}" target="_blank">PDF</a><br><span class="small">${esc(b.catalog_review_status||'书目已核')}${b.ocr_pending_pages?'<br>图页待处理 '+b.ocr_pending_pages:''}${b.ocr_candidate_pages?'<br>OCR 待核 '+b.ocr_candidate_pages:''}</span></td></tr>`).join('')+'</tbody></table>';
const pending=books.reduce((n,b)=>n+b.pending_records,0);
$('#notice').textContent=`${books.length} 份文献。待详细摘要的正文片段 ${pending.toLocaleString('zh-CN')} 条。OCR 和书目审查进度见上方书目表。`;
function chapters() {
    const old = $('#chapter').value;
    const book = $('#book').value;
    $('#chapter').innerHTML = '<option value="">全部章节</option>';
    const names = new Set(records.filter(x => !book || x.book_id === book).map(x => x.chapter));
    for (const name of sortedBy(names, name => name)) addOption('#chapter', name, name);
    if (names.has(old)) $('#chapter').value = old;
}
function find() {
    const terms = $('#q').value.trim().split(/\s+/).filter(Boolean);
    const direct = terms.length === 1 ? byid.get(terms[0]) : undefined;
    const expand = $('#aliases').checked;
    const variants = terms.map(term =>
        [term,...(expand && Object.hasOwn(aliases,term) ? aliases[term] : [])].map(norm));
    const form = $('#form').value, subject = $('#subject').value, creator = $('#creator').value;
    const book = $('#book').value, chapter = $('#chapter').value;
    const scope = $('#scope').value, status = $('#status').value;
    matched = records.filter(record => {
        if ((form && record.form!==form) || (subject && !record.subjects.includes(subject))
            || (book && record.book_id!==book) || (chapter && record.chapter!==chapter)) return false;
        if (creator && !record.creators.some(agent=>agent.agent_id===creator)) return false;
        if (scope!=='all' && !(scope==='body' && record.section_type==='body'
            && record.record_type==='text') && scope!==record.record_type) return false;
        if ((status==='detailed' && !record.summary_zh) || (status==='pending' && record.summary_zh)) return false;
        if (direct) return direct===record;
        if (!terms.length) return true;
        const content = norm([record.id,record.reference_code,record.form,record.subjects.join(' '),
            record.book_title,record.book_author,record.chapter,record.text,record.summary_zh,record.uses_zh].join(' '));
        return variants.every(words=>words.some(word=>content.includes(word)));
    });
    page=0;
    render();
}
function card(x){const flags=[x.continues_previous?'接上页':'',x.continues_next?'续下页':''].filter(Boolean).join(' / ');return `<article id="${esc(x.id)}"><b>${esc(x.reference_code)}</b> — ${esc(x.book_author)}，<i>${esc(x.book_title)}</i>，<a href="${x.source_link}" target="_blank">PDF 第 ${x.pdf_page} 页</a><br><span class="small">${esc(x.id)} | ${esc(x.chapter)} | ${esc(x.summary_status)}${flags?' | '+flags:''}</span>${x.summary_zh?`<p><b>摘要：</b>${esc(x.summary_zh)}</p><p><b>用途：</b>${esc(x.uses_zh||'')}</p>`:x.local_preview?`<p><b>本地摘句：</b>${esc(x.local_preview)}</p>`:'<p>本条尚待详细中文摘要，可展开原文核读。</p>'}<details><summary>原文、文字状态、脚注与回查</summary><div class="original">${esc(x.quote_text||x.text)}</div><p class="citation"><b>完整脚注：</b>${esc(x.citation_full)}</p><p class="citation"><b>简短脚注：</b>${esc(x.citation_short)}</p><p><button data-copy="reference_code" data-id="${x.id}">复制参照号</button><button data-copy="text" data-id="${x.id}">${x.ocr_review_status?.includes('OCR待核')?'复制待核OCR':'复制原文'}</button><button data-copy="citation_full" data-id="${x.id}">复制完整脚注</button><button data-copy="citation_short" data-id="${x.id}">复制简短脚注</button> <span id="copy-${x.id}" class="small"></span></p><p class="small">${esc(x.citation_status||"")}</p><p class="small"><b>文字状态：</b>${esc(x.ocr_review_status||x.extraction_status)}${x.quality_flags?.length?'；'+esc(x.quality_flags.join('；')):''}</p>${x.attribution_role?'<p class="small">署名说明：'+esc(x.attribution_role)+'</p>':''}${x.text_corrections?.length?'<p class="small">本条文字修正：'+esc(x.text_corrections.map(c=>c.from+' → '+c.to).join('；'))+'</p>':''}<p>${x.previous_id?`<a href="#${x.previous_id}" data-record="${x.previous_id}">上一条</a>`:''} ${x.next_id?` | <a href="#${x.next_id}" data-record="${x.next_id}">下一条</a>`:''}</p></details></article>`}
function render(){const pages=Math.max(1,Math.ceil(matched.length/pageSize));page=Math.max(0,Math.min(page,pages-1));$('#count').textContent=`找到 ${matched.length} 条；第 ${page+1} / ${pages} 页；每页 ${pageSize} 条。`;const pager=`<button data-page="${page-1}" ${page===0?'disabled':''}>上一页</button> <button data-page="${page+1}" ${page+1>=pages?'disabled':''}>下一页</button>`;$('#pager1').innerHTML=pager;$('#pager2').innerHTML=pager;$('#results').innerHTML=matched.slice(page*pageSize,(page+1)*pageSize).map(card).join('')}
async function copy(s,id){let success=false;try{await navigator.clipboard.writeText(s);success=true}catch(e){const t=document.createElement('textarea');t.value=s;document.body.append(t);t.select();success=document.execCommand('copy');t.remove()}document.getElementById('copy-'+id).textContent=success?'已复制':'未能自动复制，请选中文字复制'}
function gotoRecord(id){const x=byid.get(id);if(!x)return;$('#q').value=id;$('#book').value='';$('#chapter').value='';$('#scope').value='all';$('#status').value='';$('#form').value='';$('#subject').value='';$('#creator').value='';find();window.scrollTo(0,0)}
document.addEventListener('click',e=>{const t=e.target.closest('[data-page],[data-copy],[data-record]');if(!t)return;if(t.dataset.page!==undefined){page=Number(t.dataset.page);render();window.scrollTo(0,0)}if(t.dataset.copy)copy(t.dataset.copy==='text'?(byid.get(t.dataset.id).quote_text||byid.get(t.dataset.id).text):byid.get(t.dataset.id)[t.dataset.copy],t.dataset.id);if(t.dataset.record){e.preventDefault();gotoRecord(t.dataset.record)}});$('#searchform').addEventListener('submit',e=>{e.preventDefault();find()});$('#clear').onclick=()=>{$('#q').value='';find()};$('#book').onchange=()=>{chapters();find()};for(const id of ['chapter','scope','status','aliases','form','subject','creator'])$('#'+id).onchange=find;chapters();find();if(location.hash)gotoRecord(decodeURIComponent(location.hash.slice(1)));
