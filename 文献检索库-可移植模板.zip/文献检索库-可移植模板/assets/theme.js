(() => {
    const key = 'literature-library-theme';
    const root = document.documentElement;
    let preference;
    try { preference = localStorage.getItem(key); } catch {}
    root.dataset.theme = preference === 'dark' ? 'dark' : 'light';
    document.addEventListener('DOMContentLoaded', () => {
        const button = document.getElementById('theme-toggle');
        function update() {
            const dark = root.dataset.theme === 'dark';
            button.textContent = dark ? '切换浅色模式' : '切换深色模式';
            button.setAttribute('aria-pressed', String(dark));
        }
        button.addEventListener('click', () => {
            root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
            try { localStorage.setItem(key, root.dataset.theme); } catch {}
            update();
        });
        update();
    });
})();
