"""Incremental local extraction; uncertain pages stay explicitly pending."""
from pathlib import Path
import collections, json, re, statistics, time
import pdfplumber


def atomic(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False),encoding="utf-8");tmp.replace(path)

def split_columns(lines,width):
    """Only split when a real central gutter is visible across many lines."""
    words=[w for l in lines for w in l['words']]
    if len(lines)<15 or len(words)<100:return [(0,lines)],False
    mid=width/2;gap=max(7,width*.014)
    crossed=sum(any(w['x0']<mid+gap and w['x1']>mid-gap for w in l['words']) for l in lines)
    both=[l for l in lines if any(w['x1']<mid-gap for w in l['words']) and any(w['x0']>mid+gap for w in l['words'])]
    if crossed/max(1,len(lines))>.13 or len(both)<12:return [(0,lines)],False
    stream=[[],[]]
    for l in lines:
        for side in range(2):
            ww=[w for w in l['words'] if ((w['x0']+w['x1'])/2<mid)==(side==0)]
            if ww:
                q=dict(l);q.update(words=ww,text=' '.join(w['text'] for w in ww),x0=min(w['x0'] for w in ww),x1=max(w['x1'] for w in ww))
                stream[side].append(q)
    return list(enumerate(stream)),True

def extract(row, cache):
    S=Path(cache)
    S.mkdir(parents=True, exist_ok=True)
    bid=row['legacy_id'];dest=S/f'{bid}-records.json';ledgerfile=S/f'{bid}-pages.json';donefile=S/f'{bid}-done.json'
    if donefile.exists() and json.loads(donefile.read_text(encoding="utf-8")).get('sha256')==row['sha256']:
        return {'id':bid,'status':'cached'}
    records=[];ledger=[];chapter='正文（章节待审核）';started=time.monotonic()
    with pdfplumber.open(row['path']) as pdf:
        for pn,pg in enumerate(pdf.pages,1):
            clean=pg.dedupe_chars(tolerance=.7)
            lines=clean.extract_text_lines(x_tolerance=1,y_tolerance=3)
            good=[]
            for l in lines:
                t=l['text'].strip()
                if not t:continue
                if re.fullmatch(r'[-—–\s]*[\divxlcdmIVXLCDM]+[-—–\s]*',t) and (l['top']<pg.height*.1 or l['top']>pg.height*.9):continue
                words=[]
                # Retain word geometry to detect column gutters instead of interleaving them.
                chars=l['chars'];current=[]
                for c in chars:
                    if not c['text'].strip():
                        if current:words.append(current);current=[]
                    elif current and c['x0']-current[-1]['x1']>1.5:
                        words.append(current);current=[c]
                    else:current.append(c)
                if current:words.append(current)
                l['words']=[{'text':''.join(c['text'] for c in w),'x0':min(c['x0'] for c in w),'x1':max(c['x1'] for c in w)} for w in words]
                l['size']=statistics.median(c['size'] for c in chars) if chars else 10
                good.append(l)
            charcount=sum(len(l['text']) for l in good)
            if charcount<25:
                ledger.append({'pdf_page':pn,'status':'ocr_required' if pg.images else 'blank_or_graphic','records':0,'text_characters':charcount})
                pg.close();continue
            streams,multicol=split_columns(good,pg.width)
            font_weights=collections.Counter()
            for line in good:
                font_weights[round(line['size'],1)]+=min(len(line['text']),150)
            font=font_weights.most_common(1)[0][0]
            groups=[]
            for column,ll in streams:
                if not ll:continue
                gaps=[q['top']-p['top'] for p,q in zip(ll,ll[1:]) if 5<q['top']-p['top']<32];gap=statistics.median(gaps or [font*1.25]);base=min(l['x0'] for l in ll)
                buf=[];typ=None
                for l in ll:
                    lt='heading' if l['size']>font*1.3 else 'text'
                    if buf and (lt!=typ or l['top']-buf[-1]['top']>gap*1.45 or l['x0']>base+6 and buf[-1]['x1']<base+(pg.width/(2 if multicol else 1))*.85):
                        groups.append((column,typ,buf));buf=[]
                    buf.append(l);typ=lt
                if buf:groups.append((column,typ,buf))
            for k,(column,typ,ll) in enumerate(groups,1):
                raw='\n'.join(l['text'] for l in ll);text=raw.replace('\n',' ')
                flags=['自动提取及分段，等待独立审查']
                if multicol:flags.append('检测到双栏，已按栏重建；栏序与图注仍待核图')
                if '\x00' in text:flags.append('存在未映射字符，引用前须核图')
                if re.search(r'(\w{2,5})\1\1',text):flags.append('存在疑似重复字符，引用前须核图')
                records.append({'id':f'{bid}-{pn:06d}-{k:04d}','book_id':bid,'pdf_page':pn,'printed_page_detected':None,'record_type':typ,'section_type':'body','chapter':chapter,'text':text,'text_raw_lines':raw,'bbox':[min(l['x0'] for l in ll),min(l['top'] for l in ll),max(l['x1'] for l in ll),max(l['bottom'] for l in ll)],'column':column+1,'summary_zh':None,'uses_zh':None,'summary_status':'待详细中文摘要','extraction_status':'自动分段，待段界核查','ocr_review_status':'既有文字层提取，未逐字核图','quality_flags':flags,'record_status':'staged'})
            ledger.append({'pdf_page':pn,'status':'text_candidate','records':len(groups),'text_characters':charcount,'column_candidate':multicol,'duplicate_glyphs_removed':len(pg.chars)-len(clean.chars)})
            pg.close()
            if pn%100==0:print(bid,pn,'/',len(pdf.pages),flush=True)
    atomic(dest,records);atomic(ledgerfile,ledger)
    done={'id':bid,'sha256':row['sha256'],'pages':len(ledger),'records':len(records),'ocr_required_pages':sum(l['status']=='ocr_required' for l in ledger),'seconds':round(time.monotonic()-started,1)}
    atomic(donefile,done);return done
